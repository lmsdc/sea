# Sistema de Atendimento - SEA Telecom

## 📋 Visão Geral

Sistema web completo para atendimento ao cliente da SEA Telecom, desenvolvido com React e design moderno responsivo. O sistema oferece ferramentas essenciais para otimizar o atendimento e aumentar a produtividade da equipe.

## ✨ Funcionalidades Principais

### 🗂️ Scripts de Atendimento
- **10 scripts organizados** em 7 categorias
- **Busca inteligente** em tempo real
- **Filtros por categoria** com contadores
- **Botões "Copiar"** com feedback visual
- **Categorias disponíveis:**
  - Suporte Técnico (2 scripts)
  - Financeiro (2 scripts)
  - Retenção (1 script)
  - Comercial (1 script)
  - Instalação (1 script)
  - Cadastral (2 scripts)
  - Relacionamento (1 script)

### 🧮 Calculadoras Aprimoradas

#### Calculadora de Proporcional
- **5 campos de entrada:**
  - Plano atual (500, 600, 700, 800 MEGAS)
  - Novo plano (500, 600, 700, 800 MEGAS)
  - Data da solicitação
  - Código do cliente (para determinar ciclo)
  - Valor final da fatura
- **Cálculo automático** baseado nos ciclos de faturamento
- **Ciclos suportados:** 05, 10, 15, 20, 25, 30

#### Calculadora de Mudança de Vencimento
- **Campos específicos:**
  - Data de vencimento atual
  - Nova data de vencimento
  - Valor do plano
  - Valor final da fatura
- **Cálculo proporcional** automático

### 💬 Gerador de Texto Dinâmico
- **8 situações pré-configuradas:**
  1. **Saudação Inicial** - Nome do atendente e cliente
  2. **Agendamento de Visita** - Data, período e motivo
  3. **Cobrança Amigável** - Valores e datas de vencimento
  4. **Confirmação de Pagamento** - Detalhes da transação
  5. **Chamado Técnico** - Protocolo e prazo
  6. **Retenção de Cliente** - Ofertas personalizadas
  7. **Mudança de Endereço** - Endereços e datas
  8. **Segunda Via** - Valores e novos vencimentos

### 🔍 Sistema de Protocolo
- **Geração automática** com formato: SEA + data/hora + número aleatório
- **Geração manual** para protocolos específicos
- **Histórico de protocolos** da sessão
- **Campos de dados:**
  - Nome do cliente
  - Tipo de atendimento (9 opções)
  - Descrição detalhada
- **Botão copiar** com informações completas

### 🔗 Links Úteis
- **11 links organizados** para acesso rápido:
  - Itaú Boletos
  - Matrix Painel
  - MK Sistema
  - Connect SEA
  - Gerador de OS
  - Busque SEA
  - Lexio Legal
  - SmartOLT
  - SAC Interno
  - Wiki SEA
  - MAC Vendors

## 🎨 Interface e Experiência

### Design Moderno
- **Layout responsivo** para desktop e mobile
- **Navegação em abas** organizada
- **Cores consistentes** com identidade visual
- **Ícones intuitivos** (Lucide React)
- **Feedback visual** em todas as interações

### Usabilidade
- **Busca em tempo real** sem necessidade de botões
- **Contadores dinâmicos** nos filtros
- **Botões "Copiar"** com confirmação visual
- **Formulários intuitivos** com validação
- **Interface limpa** e profissional

## 📊 Estatísticas do Projeto

- ✅ **10 scripts** de atendimento prontos
- ✅ **8 modelos** de texto dinâmico
- ✅ **7 categorias** organizadas
- ✅ **2 calculadoras** especializadas
- ✅ **11 links úteis** integrados
- ✅ **100% responsivo** para todos os dispositivos

## 🚀 Tecnologias Utilizadas

- **React 18** - Framework principal
- **Tailwind CSS** - Estilização
- **Shadcn/UI** - Componentes de interface
- **Lucide React** - Ícones
- **Vite** - Build tool
- **JavaScript ES6+** - Linguagem

## 📱 Compatibilidade

- ✅ **Desktop** - Todas as resoluções
- ✅ **Tablet** - Layout adaptativo
- ✅ **Mobile** - Interface otimizada
- ✅ **Navegadores modernos** - Chrome, Firefox, Safari, Edge

## 🔧 Como Usar

1. **Navegação:** Use as abas superiores para alternar entre funcionalidades
2. **Scripts:** Busque por palavra-chave ou filtre por categoria
3. **Calculadoras:** Preencha os campos e clique em "Calcular"
4. **Gerador de Texto:** Selecione a situação e preencha os dados
5. **Protocolo:** Escolha o modo (automático/manual) e gere o protocolo
6. **Links Úteis:** Clique em "Abrir" para acessar os sistemas

## 📈 Benefícios

- **Aumento da produtividade** no atendimento
- **Padronização** de respostas e procedimentos
- **Redução de erros** em cálculos
- **Acesso rápido** a sistemas essenciais
- **Melhoria na experiência** do cliente
- **Organização** de protocolos e histórico

## 🎯 Próximos Passos

O sistema está pronto para uso imediato e pode ser:
- Hospedado em servidor web
- Integrado com sistemas existentes
- Expandido com novas funcionalidades
- Personalizado conforme necessidades específicas

---

**Desenvolvido para SEA Telecom** - Sistema de Atendimento Completo
*Versão 1.0 - Julho 2025*

