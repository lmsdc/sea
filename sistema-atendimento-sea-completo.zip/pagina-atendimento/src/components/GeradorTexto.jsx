import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { MessageSquare, Copy, Check } from 'lucide-react'

const situacoes = {
  saudacao: {
    nome: 'Saudação Inicial',
    campos: ['nomeAtendente', 'nomeCliente'],
    template: (dados) => `Olá ${dados.nomeCliente}, meu nome é ${dados.nomeAtendente} e estarei te atendendo hoje. Como posso ajudá-lo?`
  },
  agendamento: {
    nome: 'Agendamento de Visita',
    campos: ['nomeCliente', 'data', 'periodo', 'motivo'],
    template: (dados) => `Olá ${dados.nomeCliente}, confirmamos o agendamento da sua visita para o dia ${dados.data} no período ${dados.periodo}. Motivo: ${dados.motivo}. Nossa equipe estará no local no horário combinado. Qualquer dúvida, entre em contato conosco.`
  },
  cobranca: {
    nome: 'Cobrança Amigável',
    campos: ['nomeCliente', 'valor', 'dataVencimento'],
    template: (dados) => `Prezado(a) ${dados.nomeCliente}, identificamos que sua fatura no valor de R$ ${dados.valor} com vencimento em ${dados.dataVencimento} ainda não foi quitada. Para evitar a suspensão dos serviços, solicitamos a regularização o quanto antes. Caso já tenha efetuado o pagamento, desconsidere esta mensagem.`
  },
  confirmacao: {
    nome: 'Confirmação de Pagamento',
    campos: ['nomeCliente', 'valor', 'dataTransacao', 'formaPagamento'],
    template: (dados) => `${dados.nomeCliente}, confirmamos o recebimento do seu pagamento no valor de R$ ${dados.valor} realizado em ${dados.dataTransacao} via ${dados.formaPagamento}. Sua conta está regularizada. Obrigado pela preferência!`
  },
  chamado: {
    nome: 'Chamado Técnico',
    campos: ['nomeCliente', 'protocolo', 'prazo', 'problema'],
    template: (dados) => `${dados.nomeCliente}, seu chamado técnico foi registrado com o protocolo ${dados.protocolo}. Problema reportado: ${dados.problema}. Nossa equipe técnica irá resolver a questão em até ${dados.prazo}. Acompanhe o status pelo nosso sistema.`
  },
  retencao: {
    nome: 'Retenção de Cliente',
    campos: ['nomeCliente', 'oferta', 'desconto', 'validade'],
    template: (dados) => `${dados.nomeCliente}, não queremos perdê-lo como cliente! Temos uma oferta especial para você: ${dados.oferta} com ${dados.desconto} de desconto. Esta promoção é válida até ${dados.validade}. Entre em contato conosco para mais detalhes.`
  },
  mudancaEndereco: {
    nome: 'Mudança de Endereço',
    campos: ['nomeCliente', 'enderecoAntigo', 'enderecoNovo', 'dataTransferencia'],
    template: (dados) => `${dados.nomeCliente}, confirmamos a solicitação de mudança de endereço. Endereço atual: ${dados.enderecoAntigo}. Novo endereço: ${dados.enderecoNovo}. Data prevista para transferência: ${dados.dataTransferencia}. Nossa equipe entrará em contato para agendar a instalação.`
  },
  segundaVia: {
    nome: 'Segunda Via',
    campos: ['nomeCliente', 'valor', 'novoVencimento', 'linkBoleto'],
    template: (dados) => `${dados.nomeCliente}, sua segunda via foi gerada com sucesso! Valor: R$ ${dados.valor}. Novo vencimento: ${dados.novoVencimento}. ${dados.linkBoleto ? `Link para download: ${dados.linkBoleto}` : 'O boleto será enviado por email em alguns minutos.'}`
  }
}

export default function GeradorTexto() {
  const [situacaoSelecionada, setSituacaoSelecionada] = useState('')
  const [dados, setDados] = useState({})
  const [textoGerado, setTextoGerado] = useState('')
  const [copiado, setCopiado] = useState(false)

  const handleSituacaoChange = (situacao) => {
    setSituacaoSelecionada(situacao)
    setDados({})
    setTextoGerado('')
  }

  const handleDadoChange = (campo, valor) => {
    setDados(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const gerarTexto = () => {
    if (!situacaoSelecionada) {
      alert('Por favor, selecione uma situação')
      return
    }

    const situacao = situacoes[situacaoSelecionada]
    const camposObrigatorios = situacao.campos.filter(campo => campo !== 'linkBoleto')
    
    const camposFaltando = camposObrigatorios.filter(campo => !dados[campo] || dados[campo].trim() === '')
    
    if (camposFaltando.length > 0) {
      alert(`Por favor, preencha os campos obrigatórios: ${camposFaltando.join(', ')}`)
      return
    }

    const texto = situacao.template(dados)
    setTextoGerado(texto)
  }

  const copiarTexto = () => {
    if (!textoGerado) return

    navigator.clipboard.writeText(textoGerado)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  const getCampoLabel = (campo) => {
    const labels = {
      nomeAtendente: 'Nome do Atendente',
      nomeCliente: 'Nome do Cliente',
      data: 'Data',
      periodo: 'Período',
      motivo: 'Motivo',
      valor: 'Valor (R$)',
      dataVencimento: 'Data de Vencimento',
      dataTransacao: 'Data da Transação',
      formaPagamento: 'Forma de Pagamento',
      protocolo: 'Número do Protocolo',
      prazo: 'Prazo para Resolução',
      problema: 'Descrição do Problema',
      oferta: 'Oferta Especial',
      desconto: 'Desconto',
      validade: 'Validade da Oferta',
      enderecoAntigo: 'Endereço Atual',
      enderecoNovo: 'Novo Endereço',
      dataTransferencia: 'Data da Transferência',
      novoVencimento: 'Novo Vencimento',
      linkBoleto: 'Link do Boleto (opcional)'
    }
    return labels[campo] || campo
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MessageSquare className="w-5 h-5" />
          <span>Gerador de Texto Dinâmico</span>
        </CardTitle>
        <CardDescription>
          8 situações pré-configuradas para atendimento personalizado
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="situacao">Situação</Label>
          <Select value={situacaoSelecionada} onValueChange={handleSituacaoChange}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione uma situação" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(situacoes).map(([key, situacao]) => (
                <SelectItem key={key} value={key}>
                  {situacao.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {situacaoSelecionada && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">
              {situacoes[situacaoSelecionada].nome}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {situacoes[situacaoSelecionada].campos.map((campo) => (
                <div key={campo} className="space-y-2">
                  <Label htmlFor={campo}>
                    {getCampoLabel(campo)}
                    {campo !== 'linkBoleto' && <span className="text-red-500">*</span>}
                  </Label>
                  {campo === 'problema' || campo === 'oferta' ? (
                    <Textarea
                      id={campo}
                      value={dados[campo] || ''}
                      onChange={(e) => handleDadoChange(campo, e.target.value)}
                      placeholder={`Digite ${getCampoLabel(campo).toLowerCase()}`}
                      rows={3}
                    />
                  ) : (
                    <Input
                      id={campo}
                      value={dados[campo] || ''}
                      onChange={(e) => handleDadoChange(campo, e.target.value)}
                      placeholder={`Digite ${getCampoLabel(campo).toLowerCase()}`}
                    />
                  )}
                </div>
              ))}
            </div>

            <Button onClick={gerarTexto} className="w-full">
              <MessageSquare className="w-4 h-4 mr-2" />
              Gerar Texto
            </Button>
          </div>
        )}

        {textoGerado && (
          <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle className="text-green-900 dark:text-green-100">
                Texto Gerado
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
                <p className="text-sm leading-relaxed">{textoGerado}</p>
              </div>

              <Button onClick={copiarTexto} variant="outline" className="w-full">
                {copiado ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar Texto
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
          <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
            Situações Disponíveis:
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-blue-800 dark:text-blue-200">
            {Object.values(situacoes).map((situacao, index) => (
              <div key={index}>• {situacao.nome}</div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

