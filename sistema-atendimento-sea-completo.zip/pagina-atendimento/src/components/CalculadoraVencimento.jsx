import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Calendar, Copy, Check } from 'lucide-react'

const ciclosFaturamento = {
  '05': { abertura: 1, fechamento: 30 },
  '10': { abertura: 1, fechamento: 30 },
  '15': { abertura: 11, fechamento: 10 },
  '20': { abertura: 11, fechamento: 10 },
  '25': { abertura: 21, fechamento: 20 },
  '30': { abertura: 21, fechamento: 20 }
}

export default function CalculadoraVencimento() {
  const [vencimentoAtual, setVencimentoAtual] = useState('')
  const [novoVencimento, setNovoVencimento] = useState('')
  const [valorPlano, setValorPlano] = useState('')
  const [valorFinalFatura, setValorFinalFatura] = useState('')
  const [resultado, setResultado] = useState(null)
  const [copiado, setCopiado] = useState(false)

  const calcularMudancaVencimento = () => {
    if (!vencimentoAtual || !novoVencimento || !valorPlano || !valorFinalFatura) {
      alert('Por favor, preencha todos os campos')
      return
    }

    const vencAtual = parseInt(vencimentoAtual)
    const vencNovo = parseInt(novoVencimento)
    const valorPlan = parseFloat(valorPlano)
    const valorFinal = parseFloat(valorFinalFatura)

    // Determinar ciclo atual baseado no vencimento atual
    let cicloAtual = '05'
    if (vencAtual <= 10) cicloAtual = '05'
    else if (vencAtual <= 15) cicloAtual = '10'
    else if (vencAtual <= 20) cicloAtual = '15'
    else if (vencAtual <= 25) cicloAtual = '20'
    else if (vencAtual <= 30) cicloAtual = '25'
    else cicloAtual = '30'

    // Determinar novo ciclo baseado no novo vencimento
    let novoCiclo = '05'
    if (vencNovo <= 10) novoCiclo = '05'
    else if (vencNovo <= 15) novoCiclo = '10'
    else if (vencNovo <= 20) novoCiclo = '15'
    else if (vencNovo <= 25) novoCiclo = '20'
    else if (vencNovo <= 30) novoCiclo = '25'
    else novoCiclo = '30'

    const cicloAtualInfo = ciclosFaturamento[cicloAtual]
    const novoCicloInfo = ciclosFaturamento[novoCiclo]

    // Calcular dias proporcionais
    let diasCicloAtual, diasNovoCiclo

    // Para o ciclo atual (até a mudança)
    if (cicloAtualInfo.abertura <= cicloAtualInfo.fechamento) {
      diasCicloAtual = vencimentoAtual - cicloAtualInfo.abertura
    } else {
      if (vencimentoAtual >= cicloAtualInfo.abertura) {
        diasCicloAtual = vencimentoAtual - cicloAtualInfo.abertura
      } else {
        diasCicloAtual = (30 - cicloAtualInfo.abertura + 1) + (vencimentoAtual - 1)
      }
    }

    // Para o novo ciclo (da mudança até o novo vencimento)
    if (novoCicloInfo.abertura <= novoCicloInfo.fechamento) {
      diasNovoCiclo = novoCicloInfo.fechamento - novoCicloInfo.abertura + 1
    } else {
      diasNovoCiclo = (30 - novoCicloInfo.abertura + 1) + novoCicloInfo.fechamento
    }

    const valorProporcional = valorFinal - valorPlan
    const valorPorDia = valorPlan / 30

    setResultado({
      vencimentoAtual,
      novoVencimento,
      valorPlano: valorPlan,
      valorFinalFatura: valorFinal,
      valorProporcional,
      diasCicloAtual,
      diasNovoCiclo,
      valorPorDia,
      cicloAtualInfo,
      novoCicloInfo
    })
  }

  const copiarResultado = () => {
    if (!resultado) return

    const texto = `🔹 Cálculo de Mudança de Vencimento

Vencimento atual: dia ${resultado.vencimentoAtual}
Novo vencimento: dia ${resultado.novoVencimento}
Valor do plano: R$ ${resultado.valorPlano.toFixed(2)}
Valor final da fatura: R$ ${resultado.valorFinalFatura.toFixed(2)}
Valor proporcional: R$ ${resultado.valorProporcional.toFixed(2)}

📅 Detalhamento do cálculo:
- Valor por dia: R$ ${resultado.valorPorDia.toFixed(2)}
- Ajuste proporcional aplicado conforme novo ciclo de faturamento

🔹 Resumo:
Valor do plano: R$ ${resultado.valorPlano.toFixed(2)}
Valor proporcional: R$ ${resultado.valorProporcional.toFixed(2)}
Total da fatura: R$ ${resultado.valorFinalFatura.toFixed(2)}`

    navigator.clipboard.writeText(texto)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Calendar className="w-5 h-5" />
          <span>Calculadora de Mudança de Vencimento</span>
        </CardTitle>
        <CardDescription>
          Calcule o valor proporcional para mudança de data de vencimento
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="vencimento-atual">Data de Vencimento Atual</Label>
            <Input
              id="vencimento-atual"
              type="number"
              min="1"
              max="30"
              value={vencimentoAtual}
              onChange={(e) => setVencimentoAtual(e.target.value)}
              placeholder="Ex: 30"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="novo-vencimento">Nova Data de Vencimento</Label>
            <Input
              id="novo-vencimento"
              type="number"
              min="1"
              max="30"
              value={novoVencimento}
              onChange={(e) => setNovoVencimento(e.target.value)}
              placeholder="Ex: 15"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="valor-plano">Valor do Plano (R$)</Label>
            <Input
              id="valor-plano"
              type="number"
              step="0.01"
              value={valorPlano}
              onChange={(e) => setValorPlano(e.target.value)}
              placeholder="Ex: 99.00"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="valor-final">Valor Final da Fatura (R$)</Label>
            <Input
              id="valor-final"
              type="number"
              step="0.01"
              value={valorFinalFatura}
              onChange={(e) => setValorFinalFatura(e.target.value)}
              placeholder="Ex: 120.00"
            />
          </div>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Ciclos de Faturamento:</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
            <div>05: Todo dia 01 → 30</div>
            <div>10: Todo dia 01 → 30</div>
            <div>15: Todo dia 11 → 10</div>
            <div>20: Todo dia 11 → 10</div>
            <div>25: Todo dia 21 → 20</div>
            <div>30: Todo dia 21 → 20</div>
          </div>
        </div>

        <Button onClick={calcularMudancaVencimento} className="w-full">
          <Calendar className="w-4 h-4 mr-2" />
          Calcular Mudança de Vencimento
        </Button>

        {resultado && (
          <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle className="text-green-900 dark:text-green-100">
                Resultado do Cálculo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p><strong>Vencimento atual:</strong> dia {resultado.vencimentoAtual}</p>
                  <p><strong>Novo vencimento:</strong> dia {resultado.novoVencimento}</p>
                  <p><strong>Valor do plano:</strong> R$ {resultado.valorPlano.toFixed(2)}</p>
                </div>
                <div>
                  <p><strong>Valor final da fatura:</strong> R$ {resultado.valorFinalFatura.toFixed(2)}</p>
                  <p><strong>Valor proporcional:</strong> R$ {resultado.valorProporcional.toFixed(2)}</p>
                  <p><strong>Valor por dia:</strong> R$ {resultado.valorPorDia.toFixed(2)}</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
                <h4 className="font-semibold mb-2">Resumo:</h4>
                <p className="text-sm mb-1">
                  Valor do plano: R$ {resultado.valorPlano.toFixed(2)}
                </p>
                <p className="text-sm mb-1">
                  Valor proporcional: R$ {resultado.valorProporcional.toFixed(2)}
                </p>
                <p className="text-sm font-semibold text-green-600 dark:text-green-400">
                  🔹 Total da fatura: R$ {resultado.valorFinalFatura.toFixed(2)}
                </p>
              </div>

              <Button onClick={copiarResultado} variant="outline" className="w-full">
                {copiado ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar Resultado
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  )
}

