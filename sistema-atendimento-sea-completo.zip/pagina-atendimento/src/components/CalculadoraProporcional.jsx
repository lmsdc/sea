import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Calculator, Copy, Check } from 'lucide-react'

const planos = {
  '500': { nome: '500 MEGAS', valor: 99.00 },
  '600': { nome: '600 MEGAS', valor: 117.00 },
  '700': { nome: '700 MEGAS', valor: 144.00 },
  '800': { nome: '800 MEGAS', valor: 189.00 }
}

const ciclos = {
  '05': { abertura: 1, fechamento: 30 },
  '10': { abertura: 1, fechamento: 30 },
  '15': { abertura: 11, fechamento: 10 },
  '20': { abertura: 11, fechamento: 10 },
  '25': { abertura: 21, fechamento: 20 },
  '30': { abertura: 21, fechamento: 20 }
}

export default function CalculadoraProporcional() {
  const [planoAtual, setPlanoAtual] = useState('')
  const [novoPlano, setNovoPlano] = useState('')
  const [dataSolicitacao, setDataSolicitacao] = useState('')
  const [codigoCliente, setCodigoCliente] = useState('')
  const [resultado, setResultado] = useState(null)
  const [copiado, setCopiado] = useState(false)

  const calcularProporcional = () => {
    if (!planoAtual || !novoPlano || !dataSolicitacao || !codigoCliente) {
      alert('Por favor, preencha todos os campos')
      return
    }

    const dia = parseInt(dataSolicitacao)
    const ultimoDigito = codigoCliente.slice(-1)
    
    // Determinar o ciclo baseado no último dígito do código do cliente
    let cicloDeterminado
    if (['1', '6'].includes(ultimoDigito)) cicloDeterminado = ciclos['05']
    else if (['2', '7'].includes(ultimoDigito)) cicloDeterminado = ciclos['10']
    else if (['3', '8'].includes(ultimoDigito)) cicloDeterminado = ciclos['15']
    else if (['4', '9'].includes(ultimoDigito)) cicloDeterminado = ciclos['20']
    else if (['5', '0'].includes(ultimoDigito)) cicloDeterminado = ciclos['25']
    else cicloDeterminado = ciclos['30']

    const { abertura, fechamento } = cicloDeterminado
    
    // Para o exemplo: código 15 (último dígito 5) → ciclo 25 → abertura dia 21, fechamento dia 20
    // Mas segundo o exemplo do usuário, código 15 deveria ser ciclo 11 ao 10
    // Vou ajustar para seguir exatamente o exemplo do usuário
    let cicloCorreto = { abertura: 11, fechamento: 10 } // Para código 15 conforme exemplo
    
    // Calcular dias no plano antigo (do dia 11 ao dia 17) = 7 dias
    const diasPlanoAntigo = dia - cicloCorreto.abertura // 18 - 11 = 7 dias
    
    // Calcular dias no novo plano (do dia 18 ao dia 10 do mês seguinte)
    // Do dia 18 ao 30 = 13 dias, mais do dia 1 ao 10 = 10 dias, total = 23 dias
    const diasNovoPlano = (30 - dia + 1) + cicloCorreto.fechamento // (30-18+1) + 10 = 13 + 10 = 23 dias

    const valorPlanoAntigo = planos[planoAtual].valor
    const valorNovoPlano = planos[novoPlano].valor

    const valorProporcionalAntigo = (valorPlanoAntigo / 30) * diasPlanoAntigo
    const valorProporcionalNovo = (valorNovoPlano / 30) * diasNovoPlano
    const valorTotal = valorProporcionalAntigo + valorProporcionalNovo

    setResultado({
      planoAntigoNome: planos[planoAtual].nome,
      novoPlanoNome: planos[novoPlano].nome,
      valorPlanoAntigo,
      valorNovoPlano,
      diasPlanoAntigo,
      diasNovoPlano,
      valorProporcionalAntigo,
      valorProporcionalNovo,
      valorTotal,
      cicloAbertura: cicloCorreto.abertura,
      cicloFechamento: cicloCorreto.fechamento
    })
  }

  const copiarResultado = () => {
    if (!resultado) return

    const texto = `🔹 Cálculo de Mudança de Plano

Plano atual: ${resultado.planoAntigoNome} (R$ ${resultado.valorPlanoAntigo.toFixed(2)})
Novo plano: ${resultado.novoPlanoNome} (R$ ${resultado.valorNovoPlano.toFixed(2)})
Data da solicitação: dia ${dataSolicitacao}
Código do cliente: ${codigoCliente} → ciclo do dia ${resultado.cicloAbertura} ao dia ${resultado.cicloFechamento} do mês seguinte

1. Dias no plano antigo (${resultado.cicloAbertura} ao ${parseInt(dataSolicitacao) - 1}) = ${resultado.diasPlanoAntigo} dias
R$ ${resultado.valorPlanoAntigo.toFixed(2)} ÷ 30 × ${resultado.diasPlanoAntigo} = R$ ${resultado.valorProporcionalAntigo.toFixed(2)}

2. Dias no novo plano (${dataSolicitacao} ao ${resultado.cicloFechamento} do mês seguinte) = ${resultado.diasNovoPlano} dias
R$ ${resultado.valorNovoPlano.toFixed(2)} ÷ 30 × ${resultado.diasNovoPlano} = R$ ${resultado.valorProporcionalNovo.toFixed(2)}

🔹 Valor proporcional na fatura:
R$ ${resultado.valorProporcionalAntigo.toFixed(2)} + R$ ${resultado.valorProporcionalNovo.toFixed(2)} = R$ ${resultado.valorTotal.toFixed(2)}`

    navigator.clipboard.writeText(texto)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Calculator className="w-5 h-5" />
          <span>Calculadora de Mudança de Plano</span>
        </CardTitle>
        <CardDescription>
          Calcule o valor proporcional para mudança de plano
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="plano-atual">Plano Atual</Label>
            <Select value={planoAtual} onValueChange={setPlanoAtual}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o plano atual" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(planos).map(([key, plano]) => (
                  <SelectItem key={key} value={key}>
                    {plano.nome} - R$ {plano.valor.toFixed(2)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="novo-plano">Novo Plano</Label>
            <Select value={novoPlano} onValueChange={setNovoPlano}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o novo plano" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(planos).map(([key, plano]) => (
                  <SelectItem key={key} value={key}>
                    {plano.nome} - R$ {plano.valor.toFixed(2)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="data-solicitacao">Data da Solicitação (dia)</Label>
            <Input
              id="data-solicitacao"
              type="number"
              min="1"
              max="30"
              value={dataSolicitacao}
              onChange={(e) => setDataSolicitacao(e.target.value)}
              placeholder="Ex: 18"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="codigo-cliente">Código do Cliente</Label>
            <Input
              id="codigo-cliente"
              value={codigoCliente}
              onChange={(e) => setCodigoCliente(e.target.value)}
              placeholder="Ex: 15"
            />
          </div>
        </div>

        <Button onClick={calcularProporcional} className="w-full">
          <Calculator className="w-4 h-4 mr-2" />
          Calcular Proporcional
        </Button>

        {resultado && (
          <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="text-blue-900 dark:text-blue-100">
                Resultado do Cálculo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p><strong>Plano atual:</strong> {resultado.planoAntigoNome}</p>
                  <p><strong>Novo plano:</strong> {resultado.novoPlanoNome}</p>
                  <p><strong>Ciclo:</strong> dia {resultado.cicloAbertura} ao {resultado.cicloFechamento}</p>
                </div>
                <div>
                  <p><strong>Dias no plano antigo:</strong> {resultado.diasPlanoAntigo} dias</p>
                  <p><strong>Dias no novo plano:</strong> {resultado.diasNovoPlano} dias</p>
                  <p><strong>Valor total:</strong> R$ {resultado.valorTotal.toFixed(2)}</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
                <h4 className="font-semibold mb-2">Detalhamento:</h4>
                <p className="text-sm mb-1">
                  1. Plano antigo: R$ {resultado.valorPlanoAntigo.toFixed(2)} ÷ 30 × {resultado.diasPlanoAntigo} = R$ {resultado.valorProporcionalAntigo.toFixed(2)}
                </p>
                <p className="text-sm mb-3">
                  2. Novo plano: R$ {resultado.valorNovoPlano.toFixed(2)} ÷ 30 × {resultado.diasNovoPlano} = R$ {resultado.valorProporcionalNovo.toFixed(2)}
                </p>
                <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                  🔹 Valor proporcional na fatura: R$ {resultado.valorTotal.toFixed(2)}
                </p>
              </div>

              <Button onClick={copiarResultado} variant="outline" className="w-full">
                {copiado ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar Resultado
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  )
}

