import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Search, Copy, Check, RefreshCw, Hash } from 'lucide-react'

const tiposAtendimento = [
  'Suporte Técnico',
  'Financeiro',
  'Comercial',
  'Instalação',
  'Cancelamento',
  'Mudança de Endereço',
  'Reclamação',
  'Elogio',
  'Outros'
]

export default function SistemaProtocolo() {
  const [modoAutomatico, setModoAutomatico] = useState(true)
  const [protocoloGerado, setProtocoloGerado] = useState('')
  const [dadosProtocolo, setDadosProtocolo] = useState({
    nomeCliente: '',
    tipoAtendimento: '',
    descricao: '',
    protocoloManual: ''
  })
  const [copiado, setCopiado] = useState(false)
  const [historico, setHistorico] = useState([])

  const gerarProtocoloAutomatico = () => {
    const agora = new Date()
    const ano = agora.getFullYear()
    const mes = String(agora.getMonth() + 1).padStart(2, '0')
    const dia = String(agora.getDate()).padStart(2, '0')
    const hora = String(agora.getHours()).padStart(2, '0')
    const minuto = String(agora.getMinutes()).padStart(2, '0')
    const segundo = String(agora.getSeconds()).padStart(2, '0')
    
    // Formato: SEA + AAAAMMDD + HHMMSS + número aleatório de 3 dígitos
    const numeroAleatorio = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
    const protocolo = `SEA${ano}${mes}${dia}${hora}${minuto}${segundo}${numeroAleatorio}`
    
    setProtocoloGerado(protocolo)
    
    // Adicionar ao histórico se tiver dados completos
    if (dadosProtocolo.nomeCliente && dadosProtocolo.tipoAtendimento) {
      const novoRegistro = {
        protocolo,
        nomeCliente: dadosProtocolo.nomeCliente,
        tipoAtendimento: dadosProtocolo.tipoAtendimento,
        descricao: dadosProtocolo.descricao,
        dataHora: agora.toLocaleString('pt-BR'),
        modo: 'Automático'
      }
      setHistorico(prev => [novoRegistro, ...prev.slice(0, 9)]) // Manter apenas os 10 mais recentes
    }
  }

  const gerarProtocoloManual = () => {
    if (!dadosProtocolo.protocoloManual.trim()) {
      alert('Por favor, digite o protocolo manual')
      return
    }

    setProtocoloGerado(dadosProtocolo.protocoloManual)
    
    // Adicionar ao histórico
    if (dadosProtocolo.nomeCliente && dadosProtocolo.tipoAtendimento) {
      const novoRegistro = {
        protocolo: dadosProtocolo.protocoloManual,
        nomeCliente: dadosProtocolo.nomeCliente,
        tipoAtendimento: dadosProtocolo.tipoAtendimento,
        descricao: dadosProtocolo.descricao,
        dataHora: new Date().toLocaleString('pt-BR'),
        modo: 'Manual'
      }
      setHistorico(prev => [novoRegistro, ...prev.slice(0, 9)])
    }
  }

  const copiarProtocolo = () => {
    if (!protocoloGerado) return

    let texto = `Protocolo: ${protocoloGerado}`
    
    if (dadosProtocolo.nomeCliente) {
      texto += `\nCliente: ${dadosProtocolo.nomeCliente}`
    }
    
    if (dadosProtocolo.tipoAtendimento) {
      texto += `\nTipo: ${dadosProtocolo.tipoAtendimento}`
    }
    
    if (dadosProtocolo.descricao) {
      texto += `\nDescrição: ${dadosProtocolo.descricao}`
    }
    
    texto += `\nData/Hora: ${new Date().toLocaleString('pt-BR')}`

    navigator.clipboard.writeText(texto)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  const handleDadoChange = (campo, valor) => {
    setDadosProtocolo(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const limparFormulario = () => {
    setDadosProtocolo({
      nomeCliente: '',
      tipoAtendimento: '',
      descricao: '',
      protocoloManual: ''
    })
    setProtocoloGerado('')
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="w-5 h-5" />
            <span>Sistema de Protocolo</span>
          </CardTitle>
          <CardDescription>
            Geração automática e manual de protocolos de atendimento
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Seletor de Modo */}
          <div className="flex items-center space-x-4">
            <Label>Modo de Geração:</Label>
            <div className="flex space-x-2">
              <Button
                variant={modoAutomatico ? "default" : "outline"}
                size="sm"
                onClick={() => setModoAutomatico(true)}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Automático
              </Button>
              <Button
                variant={!modoAutomatico ? "default" : "outline"}
                size="sm"
                onClick={() => setModoAutomatico(false)}
              >
                <Hash className="w-4 h-4 mr-2" />
                Manual
              </Button>
            </div>
          </div>

          {/* Dados do Atendimento */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome-cliente">Nome do Cliente</Label>
              <Input
                id="nome-cliente"
                value={dadosProtocolo.nomeCliente}
                onChange={(e) => handleDadoChange('nomeCliente', e.target.value)}
                placeholder="Digite o nome do cliente"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo-atendimento">Tipo de Atendimento</Label>
              <Select value={dadosProtocolo.tipoAtendimento} onValueChange={(value) => handleDadoChange('tipoAtendimento', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  {tiposAtendimento.map((tipo) => (
                    <SelectItem key={tipo} value={tipo}>
                      {tipo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="descricao">Descrição do Atendimento</Label>
            <Textarea
              id="descricao"
              value={dadosProtocolo.descricao}
              onChange={(e) => handleDadoChange('descricao', e.target.value)}
              placeholder="Descreva brevemente o atendimento realizado"
              rows={3}
            />
          </div>

          {/* Campo para Protocolo Manual */}
          {!modoAutomatico && (
            <div className="space-y-2">
              <Label htmlFor="protocolo-manual">Protocolo Manual</Label>
              <Input
                id="protocolo-manual"
                value={dadosProtocolo.protocoloManual}
                onChange={(e) => handleDadoChange('protocoloManual', e.target.value)}
                placeholder="Digite o protocolo manualmente"
              />
            </div>
          )}

          {/* Botões de Ação */}
          <div className="flex space-x-2">
            <Button
              onClick={modoAutomatico ? gerarProtocoloAutomatico : gerarProtocoloManual}
              className="flex-1"
            >
              {modoAutomatico ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Gerar Protocolo Automático
                </>
              ) : (
                <>
                  <Hash className="w-4 h-4 mr-2" />
                  Registrar Protocolo Manual
                </>
              )}
            </Button>
            <Button variant="outline" onClick={limparFormulario}>
              Limpar
            </Button>
          </div>

          {/* Protocolo Gerado */}
          {protocoloGerado && (
            <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
              <CardHeader>
                <CardTitle className="text-green-900 dark:text-green-100">
                  Protocolo Gerado
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
                  <div className="text-center">
                    <div className="text-2xl font-mono font-bold text-green-600 dark:text-green-400 mb-2">
                      {protocoloGerado}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">
                      Gerado em: {new Date().toLocaleString('pt-BR')}
                    </div>
                  </div>
                  
                  {(dadosProtocolo.nomeCliente || dadosProtocolo.tipoAtendimento || dadosProtocolo.descricao) && (
                    <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                      {dadosProtocolo.nomeCliente && (
                        <p><strong>Cliente:</strong> {dadosProtocolo.nomeCliente}</p>
                      )}
                      {dadosProtocolo.tipoAtendimento && (
                        <p><strong>Tipo:</strong> {dadosProtocolo.tipoAtendimento}</p>
                      )}
                      {dadosProtocolo.descricao && (
                        <p><strong>Descrição:</strong> {dadosProtocolo.descricao}</p>
                      )}
                    </div>
                  )}
                </div>

                <Button onClick={copiarProtocolo} variant="outline" className="w-full">
                  {copiado ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copiar Protocolo
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Histórico de Protocolos */}
      {historico.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Histórico de Protocolos</CardTitle>
            <CardDescription>
              Últimos protocolos gerados nesta sessão
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {historico.map((registro, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-semibold">{registro.protocolo}</span>
                      <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-1 rounded">
                        {registro.modo}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">
                      {registro.nomeCliente} • {registro.tipoAtendimento} • {registro.dataHora}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      navigator.clipboard.writeText(registro.protocolo)
                    }}
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

