import { useState, useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { FileText, Search, Copy, Check, Filter } from 'lucide-react'

const scripts = [
  {
    id: 1,
    titulo: 'Abertura de Chamado Técnico',
    categoria: 'Suporte Técnico',
    conteudo: 'Olá, vou abrir um chamado técnico para resolver seu problema. Preciso de algumas informações: qual o problema específico que está enfrentando? Em que horário isso acontece com mais frequência? Já tentou reiniciar o equipamento?'
  },
  {
    id: 2,
    titulo: 'Cobrança em Atraso',
    categoria: 'Financeiro',
    conteudo: 'Identificamos que existe uma pendência financeira em sua conta. Para evitar a suspensão dos serviços, solicitamos a regularização. Posso verificar as opções de pagamento disponíveis e negociar condições especiais se necessário.'
  },
  {
    id: 3,
    titulo: 'Cancelamento de Serviço',
    categoria: 'Retenção',
    conteudo: 'Entendo que deseja cancelar o serviço. Antes de prosseguir, gostaria de entender o motivo e verificar se podemos resolver a questão. Temos algumas ofertas especiais que podem atender melhor às suas necessidades.'
  },
  {
    id: 4,
    titulo: 'Mudança de Plano',
    categoria: 'Comercial',
    conteudo: 'Vou ajudá-lo com a mudança de plano. Primeiro, preciso entender suas necessidades atuais de internet. Quantas pessoas usam a conexão? Que tipo de atividades realizam online? Com base nisso, posso sugerir o melhor plano.'
  },
  {
    id: 5,
    titulo: 'Instalação Agendada',
    categoria: 'Instalação',
    conteudo: 'Sua instalação foi agendada com sucesso. Nossa equipe técnica estará no local no horário combinado. É importante que tenha alguém maior de idade no endereço. Alguma dúvida sobre o processo de instalação?'
  },
  {
    id: 6,
    titulo: 'Problema de Velocidade',
    categoria: 'Suporte Técnico',
    conteudo: 'Vamos resolver essa questão de velocidade. Primeiro, vou fazer alguns testes remotos. Pode desconectar outros dispositivos e fazer um teste de velocidade? Qual velocidade está obtendo no momento?'
  },
  {
    id: 7,
    titulo: 'Segunda Via de Boleto',
    categoria: 'Financeiro',
    conteudo: 'Vou gerar sua segunda via agora mesmo. Posso enviar por email ou WhatsApp, qual prefere? O boleto terá o mesmo valor e vencimento original. Caso precise de uma nova data de vencimento, posso ajustar também.'
  },
  {
    id: 8,
    titulo: 'Transferência de Titularidade',
    categoria: 'Cadastral',
    conteudo: 'Para a transferência de titularidade, precisaremos de alguns documentos. O atual titular deve autorizar a transferência e o novo titular deve fornecer seus dados. Posso explicar todo o processo passo a passo.'
  },
  {
    id: 9,
    titulo: 'Mudança de Endereço',
    categoria: 'Cadastral',
    conteudo: 'Vou verificar a viabilidade técnica para seu novo endereço. Preciso do CEP e número da residência. Dependendo da localização, pode haver taxa de transferência. O prazo médio é de 5 a 10 dias úteis.'
  },
  {
    id: 10,
    titulo: 'Elogio ao Atendimento',
    categoria: 'Relacionamento',
    conteudo: 'Muito obrigado pelo seu elogio! Ficamos muito felizes em saber que nosso atendimento atendeu suas expectativas. Seu feedback é muito importante para continuarmos melhorando nossos serviços.'
  }
]

const categorias = [
  'Todas',
  'Suporte Técnico',
  'Financeiro',
  'Retenção',
  'Comercial',
  'Instalação',
  'Cadastral',
  'Relacionamento'
]

export default function ScriptsAtendimento() {
  const [busca, setBusca] = useState('')
  const [categoriaFiltro, setCategoriaFiltro] = useState('Todas')
  const [scriptCopiado, setScriptCopiado] = useState(null)

  const scriptsFiltrados = useMemo(() => {
    return scripts.filter(script => {
      const matchBusca = script.titulo.toLowerCase().includes(busca.toLowerCase()) ||
                        script.conteudo.toLowerCase().includes(busca.toLowerCase()) ||
                        script.categoria.toLowerCase().includes(busca.toLowerCase())
      
      const matchCategoria = categoriaFiltro === 'Todas' || script.categoria === categoriaFiltro
      
      return matchBusca && matchCategoria
    })
  }, [busca, categoriaFiltro])

  const contadorPorCategoria = useMemo(() => {
    const contador = {}
    categorias.forEach(cat => {
      if (cat === 'Todas') {
        contador[cat] = scripts.length
      } else {
        contador[cat] = scripts.filter(script => script.categoria === cat).length
      }
    })
    return contador
  }, [])

  const copiarScript = (script) => {
    const texto = `${script.titulo}\n\n${script.conteudo}`
    navigator.clipboard.writeText(texto)
    setScriptCopiado(script.id)
    setTimeout(() => setScriptCopiado(null), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="w-5 h-5" />
          <span>Scripts de Atendimento</span>
        </CardTitle>
        <CardDescription>
          Scripts organizados por 7 categorias com busca inteligente
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Busca */}
        <div className="space-y-2">
          <Label htmlFor="busca">Busca em Tempo Real</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              id="busca"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Digite para buscar scripts..."
              className="pl-10"
            />
          </div>
        </div>

        {/* Filtros por Categoria */}
        <div className="space-y-3">
          <Label className="flex items-center space-x-2">
            <Filter className="w-4 h-4" />
            <span>Filtros por Categoria</span>
          </Label>
          <div className="flex flex-wrap gap-2">
            {categorias.map((categoria) => (
              <Button
                key={categoria}
                variant={categoriaFiltro === categoria ? "default" : "outline"}
                size="sm"
                onClick={() => setCategoriaFiltro(categoria)}
                className="flex items-center space-x-1"
              >
                <span>{categoria}</span>
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contadorPorCategoria[categoria]}
                </Badge>
              </Button>
            ))}
          </div>
        </div>

        {/* Resultados */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              Scripts Encontrados ({scriptsFiltrados.length})
            </h3>
            {busca && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setBusca('')}
              >
                Limpar Busca
              </Button>
            )}
          </div>

          {scriptsFiltrados.length === 0 ? (
            <Card className="bg-gray-50 dark:bg-gray-800">
              <CardContent className="p-8 text-center">
                <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 dark:text-gray-300">
                  Nenhum script encontrado para os filtros aplicados
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {scriptsFiltrados.map((script) => (
                <Card key={script.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-base">{script.titulo}</CardTitle>
                        <Badge variant="outline" className="text-xs">
                          {script.categoria}
                        </Badge>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copiarScript(script)}
                        className="flex items-center space-x-1"
                      >
                        {scriptCopiado === script.id ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>Copiado!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copiar</span>
                          </>
                        )}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                      {script.conteudo}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Estatísticas */}
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {scripts.length}
                </div>
                <div className="text-sm text-blue-800 dark:text-blue-200">
                  Scripts Totais
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {categorias.length - 1}
                </div>
                <div className="text-sm text-blue-800 dark:text-blue-200">
                  Categorias
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {scriptsFiltrados.length}
                </div>
                <div className="text-sm text-blue-800 dark:text-blue-200">
                  Resultados
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {categoriaFiltro}
                </div>
                <div className="text-sm text-blue-800 dark:text-blue-200">
                  Filtro Ativo
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  )
}

