import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Calculator, MessageSquare, FileText, Link, Search, Settings } from 'lucide-react'
import CalculadoraProporcional from './components/CalculadoraProporcional.jsx'
import CalculadoraVencimento from './components/CalculadoraVencimento.jsx'
import GeradorTexto from './components/GeradorTexto.jsx'
import ScriptsAtendimento from './components/ScriptsAtendimento.jsx'
import SistemaProtocolo from './components/SistemaProtocolo.jsx'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('scripts')

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-lg border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Sistema de Atendimento
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  SEA Telecom - Ferramentas de Suporte
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="text-sm">
                10 Scripts • 8 Modelos • 7 Categorias
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="scripts" className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span>Scripts</span>
            </TabsTrigger>
            <TabsTrigger value="calculadoras" className="flex items-center space-x-2">
              <Calculator className="w-4 h-4" />
              <span>Calculadoras</span>
            </TabsTrigger>
            <TabsTrigger value="gerador" className="flex items-center space-x-2">
              <MessageSquare className="w-4 h-4" />
              <span>Gerador de Texto</span>
            </TabsTrigger>
            <TabsTrigger value="protocolo" className="flex items-center space-x-2">
              <Search className="w-4 h-4" />
              <span>Protocolo</span>
            </TabsTrigger>
            <TabsTrigger value="links" className="flex items-center space-x-2">
              <Link className="w-4 h-4" />
              <span>Links Úteis</span>
            </TabsTrigger>
          </TabsList>

          {/* Scripts Tab */}
          <TabsContent value="scripts" className="space-y-6">
            <ScriptsAtendimento />
          </TabsContent>

          {/* Calculadoras Tab */}
          <TabsContent value="calculadoras" className="space-y-6">
            <CalculadoraProporcional />
            <CalculadoraVencimento />
          </TabsContent>

          {/* Gerador de Texto Tab */}
          <TabsContent value="gerador" className="space-y-6">
            <GeradorTexto />
          </TabsContent>

          {/* Protocolo Tab */}
          <TabsContent value="protocolo" className="space-y-6">
            <SistemaProtocolo />
          </TabsContent>

          {/* Links Úteis Tab */}
          <TabsContent value="links" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Link className="w-5 h-5" />
                  <span>Links Úteis</span>
                </CardTitle>
                <CardDescription>
                  Acesso rápido aos sistemas e ferramentas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { name: 'Itaú Boletos', url: 'https://www.itau.com.br/servicos/boletos/atualizar?onepage_org=' },
                    { name: 'Matrix Painel', url: 'https://seatelecom.matrixdobrasil.ai/Painel/' },
                    { name: 'MK Sistema', url: 'http://mk.seatelecom.com.br:8080/mk/open.do?sys=MK0' },
                    { name: 'Connect SEA', url: 'https://connect.seasolutions.com.br/SEA/Web/Aniel.Connect/?IdAcesso=114359#!' },
                    { name: 'Gerador de OS', url: 'https://gerador-de-os.netlify.app/' },
                    { name: 'Busque SEA', url: 'https://seahub.seasolutions.com.br/busquesea' },
                    { name: 'Lexio Legal', url: 'https://app.lexio.legal/login' },
                    { name: 'SmartOLT', url: 'https://seatelecom.smartolt.com/auth/login' },
                    { name: 'SAC Interno', url: 'http://172.18.33.64/sac' },
                    { name: 'Wiki SEA', url: 'https://wikijs.seasolutions.com.br/pt-br/home' },
                    { name: 'MAC Vendors', url: 'https://macvendors.com/' }
                  ].map((link, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-medium text-sm">{link.name}</h3>
                            <p className="text-xs text-gray-500 truncate">{link.url}</p>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => window.open(link.url, '_blank')}
                          >
                            Abrir
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              © 2025 SEA Telecom - Sistema de Atendimento
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300">
              <span>10 Scripts</span>
              <span>•</span>
              <span>8 Modelos</span>
              <span>•</span>
              <span>7 Categorias</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

